<?php
	DEFINE('DB_USERNAME', 'root');
	DEFINE('DB_PASSWORD', 'root');
	DEFINE('DB_HOST','localhost:3306');
	DEFINE('DB_APP_DATABASE', 'applications_db');
	DEFINE('DB_FORM_DATABASE', 'forms_db');
?>